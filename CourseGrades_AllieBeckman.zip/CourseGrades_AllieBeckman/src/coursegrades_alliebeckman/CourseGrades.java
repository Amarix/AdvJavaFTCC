
package coursegrades_alliebeckman;

import java.util.Arrays;

public class CourseGrades {
    
    // create the array of objects
    public GradedActivity[] grades = new GradedActivity[4];
    
    // set lab method initalizing the new object with grade number already defined
    // add it to grades array at index 0
    public GradedActivity setLab (){
       GradedActivity labGrade = new GradedActivity(); // new object
       labGrade.setScore(89); // object method for numeric score
       labGrade.getGrade(); // object method for letter score
       grades[0] = labGrade; // setting the object to the array list at index 0
       return labGrade; // return the value to complete the method
    }
    
    // set lab method initalizing the new object with grade number already defined
    // add it to grades array at index 0
    public GradedActivity setPassFail (){
       GradedActivity passFailGrade = new GradedActivity();
       passFailGrade.setScore(77);
       passFailGrade.getGrade();
       grades[1] = passFailGrade;
       return passFailGrade;
    }
    
    // set lab method initalizing the new object with grade number already defined
    // add it to grades array at index 0
    public GradedActivity setEssay (){
       GradedActivity essayGrade = new GradedActivity();
       essayGrade.setScore(98);
       essayGrade.getGrade();
       grades[2] = essayGrade;
       return essayGrade;
    }
    
    // set lab method initalizing the new object with grade number already defined
    // add it to grades array at index 0
    public GradedActivity setFinal(){
       GradedActivity finalGrade = new GradedActivity();
       finalGrade.setScore(85);
       finalGrade.getGrade();
       grades[3] = finalGrade;
       return finalGrade;
    }
 
    // write a to string method to return the letter and numeric grade for each graded activity / object
    public String toString(){
        String FinalGrades = "Lab: "+grades[0].toString()+"\n"+"Pass Fail Exam: "+grades[1].toString()
                +"\n"+"Essay: "+grades[2].toString()+"\n"+"Final Exam: "+grades[3].toString();
        return FinalGrades;
    }

}
