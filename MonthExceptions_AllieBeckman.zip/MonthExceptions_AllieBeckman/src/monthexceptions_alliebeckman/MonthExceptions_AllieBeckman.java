
package monthexceptions_alliebeckman;

import javax.swing.JOptionPane;

/**
* A program that holds information about any given month but throws an exception
* if an invalid month name or number is given
* 10/5/16
* CSC 251 Lab 10 - Exception Project
* @author Allie Beckman
*/
public class MonthExceptions_AllieBeckman {

    public static void main(String[] args) {
        
        String month = JOptionPane.showInputDialog("What month will you be adding a note to?");
        String note = JOptionPane.showInputDialog("Please enter the note you'd like to save for this month: ");

        newMonth(month, note);
        
    }
    
    public static void newMonth(String mN, String note){
        Month newMonth;
        
        try{
            newMonth = new Month(mN);
            
            System.out.println("You entered: ");
            System.out.println(newMonth.getMonthName());
            System.out.println("Your note was: ");
            System.out.println(note);
            
        }catch(InvalidMonthNameException e){
            
            System.out.println(e.getMessage());
            
        }catch(InvalidMonthNumberException e){
            
            System.out.println(e.getMessage());
        }
    }

}
