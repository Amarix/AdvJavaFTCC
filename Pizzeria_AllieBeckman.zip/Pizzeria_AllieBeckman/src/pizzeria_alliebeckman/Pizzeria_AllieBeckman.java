
package pizzeria_alliebeckman;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
* An application that creates a pizza database that holds tables for pizza size, pizza crust, pizza toppings
* and allows the user to build their pizza and receive the price.
* Date
* CSC 251 Project 2 -Pizzeria
* @author Allie Beckman
*/

public class Pizzeria_AllieBeckman extends Application {
    
    @Override
    public void start(Stage stage) throws Exception {
        
        Parent root = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
        
        Scene scene = new Scene(root);
        
        stage.setScene(scene);
        stage.show();
    }
    
    public static void main(String[] args){
        launch(args);
    }
}
