/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package penniesforpay_alliebeckman;

import java.text.DecimalFormat;
import java.util.Scanner;

/**
* Display amount of pay you are earning after pay doubles each day after a user given days
* 8/17/2016
* CSC 251 Lab 3 - Pennies for Pay
* @author Allie Beckman
*/
public class PenniesForPay_AllieBeckman {

    public static void main(String[] args) {
        
        int pennies; // penny accumulator
        int totalPay; // Total pay accumulator
        int maxDays; // Max number of days
        int dayCount; // Day counter
        
        // Scanner for keyboard input
        Scanner keyboard = new Scanner(System.in);
        
        // Get the max number of days
        System.out.print("For how many days will you work? ");
        maxDays = keyboard.nextInt();
        
        // Validate the input.
        while (maxDays<1){
        // prompt the user to enter correct value
        System.out.println("The number of days mu7st be at least 1.");
        System.out.println("Enter the number of days: ");
        maxDays = keyboard.nextInt();
    }
        // Initialize the penny accumulator for
        // the first day at work
        pennies = 1;
        
        // Initalize the day counter to day 1.
        dayCount = 1;
        
        // Initalize the total pay accumulator.
        totalPay = 0;
        
        // Display the report header.
        System.out.println();
        System.out.println("Day\t\tPennies Earned");
        System.out.println("___________________________________");
        
        // Display the income report.
        while (dayCount <= maxDays)
        {
            // Display the day number and pennies earned
            System.out.println(dayCount+"\t\t"+pennies);
            
            // Accumulate the total pay
            totalPay += pennies;
            
            // Increment dayCount for the next day
            dayCount++;
            
            // Double pennies
            pennies *= 2;
        }
        
        // Create a DecimalFormat object to format output
        DecimalFormat dollar = new DecimalFormat("0.00");
        
        // Display the total pay.
        System.out.println("Total pay: $"+dollar.format(totalPay/100.0));
        
        // exit program
        System.exit(0);
    }
    
}
