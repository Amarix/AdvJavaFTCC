/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package month_alliebeckman;

public class Month {
    
    private int MonthNumber = 1; // initalize the value for the month number to be used
                            // within this class (Month)
    private String MonthName = "January"; // initalize the string value of the month for this class
    
    enum month { January, February, March, April, May, June, July, August, September, October, November, December};
    
    
    /**
     * accepts a string entered by the user and returns the int value of the string month
     * if there is no case for their entry it returns null and sets the month number to 1
     * @param monthName 
     */
    public Month(String monthName){
        
        switch (monthName.toLowerCase()){ // use a switch statement once the corrisponding string is 
                                        // collected from the main class to set the values of month name and number
            case "january":
                MonthName = "January";
                MonthNumber = 1;
                break;
            case "february":
                MonthName = "February";
                MonthNumber = 2;
                break;
            case "march":
                MonthName = "March";
                MonthNumber = 3;
                break;
            case "april":
                MonthName = "April";
                MonthNumber = 4;
                break;
            case "may":
                MonthName = "May";
                MonthNumber = 5;
                break;
            case "june":
                MonthName = "June";
                MonthNumber = 6;
                break;
            case "july":
                MonthName = "July";
                MonthNumber = 7;
                break;
            case "august":
                MonthName = "August";
                MonthNumber = 8;
                break;
            case "september":
                MonthName = "September";
                MonthNumber = 9;
                break; 
            case "october":
                MonthName = "October";
                MonthNumber = 10;
                break;    
            case "november":
                MonthName = "November";
                MonthNumber = 11;
                break;  
            case "december":
                MonthName = "December";
                MonthNumber = 12;
                break;
        }
    }
    
    public Month(int monthNumber){ // constructor for int value of month
        
        if (monthNumber >= 1 && monthNumber <= 12){ // use the if statement to default to january if it's not within bounds
            MonthNumber = monthNumber;
        }else{
            MonthNumber = 1;
        }

        switch (MonthNumber){ // use a switch statement once the corisponding int is retreaved from the main class
                              // to find the case and set the month name and number values
            case 1:
                MonthName = "January";
                MonthNumber = 1;
                break;
            case 2:
                MonthName = "February";
                MonthNumber = 2;
                break;
            case 3:
                MonthName = "March";
                MonthNumber = 3;
                break;
            case 4:
                MonthName = "April";
                MonthNumber = 4;
                break;
            case 5:
                MonthName = "May";
                MonthNumber = 5;
                break;
            case 6:
                MonthName = "June";
                MonthNumber = 6;
                break;
            case 7:
                MonthName = "July";
                MonthNumber = 7;
                break;
            case 8:
                MonthName = "August";
                MonthNumber = 8;
                break;
            case 9:
                MonthName = "September";
                MonthNumber = 9;
                break; 
            case 10:
                MonthName = "October";
                MonthNumber = 10;
                break;    
            case 11:
                MonthName = "November";
                MonthNumber = 11;
                break;  
            case 12:
                MonthName = "December";
                MonthNumber = 12;
                break;
        }
        
        
    }
    
    /**
     * a method to check if the users entered month number value is between 1 and 12
     * @param monthNumber 
     */
    public void setMonthNumber(int monthNumber){
        
       // if (monthNumber <= 0 || monthNumber >= 13){
       //     MonthName = "January";
       //     MonthNumber = 1;
       // }
    }
    
    /**
     * return MonthNumber
     * @return 
     */
    public int getMonthNumber(){
        return MonthNumber;
    }
    
    /**
     * return MonthName
     * @return 
     */
    public String getMonthName(){
        return MonthName;
    }
    
    /**
     * return both values as a string
     * @return 
     */
    public String toString(){ // this will be printed if this class is called to print. it prints the 
                              // final values obtained from the constructors.
        
        return "The month you entered is " + MonthName + " month " + Integer.toString(MonthNumber) + ".";
    }
    
    // check to see if input values and results are equal
    public boolean equals(int monthNumber, String monthName){
        
        if(monthNumber == MonthNumber|| monthName == MonthName){ // this is the only way
                                                            // that I know of to check if they're equal?
            return true;
        }else{
            return false;
        }
    }
}

