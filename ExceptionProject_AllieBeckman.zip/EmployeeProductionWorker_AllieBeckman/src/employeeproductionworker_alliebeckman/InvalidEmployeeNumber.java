
package employeeproductionworker_alliebeckman;


public class InvalidEmployeeNumber extends Exception {
    /**
     * Constructor
     */
    public InvalidEmployeeNumber(){
        super("ERROR: Invalid employee number. ");
    }
}
