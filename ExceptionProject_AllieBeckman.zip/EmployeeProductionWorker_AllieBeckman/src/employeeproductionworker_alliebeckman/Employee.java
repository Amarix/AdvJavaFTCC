
package employeeproductionworker_alliebeckman;


public class Employee {
    private String name;// name
    private String employeeNumber; // employee number
    private String hireDate; // employee hire date
    
    /**
     * This constructor initializes an object with a name, employee number,
     * and hire date.
     * @param n The name
     * @param num the number
     * @param date the hire date
     * @throws employeeproductionworker_alliebeckman.InvalidEmployeeNumber
     */ 
    
    public Employee(String n, String num, String date) throws InvalidEmployeeNumber
    {
        name = n;
        setEmployeeNumber(num);
        hireDate = date;
    }
    
    /**
     * The no-arg constructor initalizes an object with nul strings
     * for name employee number and hire date.
     */
    
    public Employee()
    {
        name = "";
        employeeNumber = "";
        hireDate = "";
    }
    
    
    /**
     * The set name method sets the employees name
     * @param n The name
     */
    
    public void setName(String n){
        name = n;
    }
    
    /**
     * The set number method sets the employees number
     * @param e The employee number
     * @throws employeeproductionworker_alliebeckman.InvalidEmployeeNumber
     */
    
    public void setEmployeeNumber(String e) throws InvalidEmployeeNumber
    {
        if (isValidEmpNum(e)){
            employeeNumber = e;
        }else{
            throw new InvalidEmployeeNumber();
        } 
    }
        
    /**
     * The hire date method sets hire date
     * @param h hire date
     */
    
    public void setHireDate(String h){
        hireDate = h;
    }
    
    /**
     * The getName method returns the employee's name.
     * @return the name
     */
    
    public String getName(){
        return name;
    }
    
    /**
     * invalid is a private method that determines whether a string is a valid
     * employee number
     * @param e the string containing an employee number
     * @return true of e references a valid ID number
     * false otherwise
     */
    
    private boolean isValidEmpNum(String e){
        boolean status = true;
        
        if (e.length() != 5){
            status = false;
        }else{
            if  ((!Character.isDigit(e.charAt(0)))||
                (!Character.isDigit(e.charAt(1)))||
                (!Character.isDigit(e.charAt(2)))||
                (e.charAt(3)!= '-')||
                (Character.toUpperCase(e.charAt(4)) < 'A')||
                (Character.toUpperCase(e.charAt(4)) > 'M')) 
            {
                status = false;
            }
        }
        
        return status;
    }
    
    /**
     * toString method
     * @return A reference to a String representation of the object
     */
    
    public String toString(){
        String str = "Name: "+ name + "\nEmployee Number: ";
        
        if (employeeNumber == ""){
            str += "INVALID EMPLOYEE NUMBER";
        }else{
            str += employeeNumber;
            
            str += ("\nHire Date: " + hireDate);
        }
        
        return str;
    }

}

