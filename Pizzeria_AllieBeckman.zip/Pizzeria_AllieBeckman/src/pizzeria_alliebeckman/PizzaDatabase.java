package pizzeria_alliebeckman;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;


public class PizzaDatabase{
    
    // create the connection variable
    private Connection connect;
    
    public void connect(){
        
        // the properties variable will enter the username and password to connect
        // to the database
        Properties connectProps = new Properties();
        // The default schema username for derby
        connectProps.put("user", "APP");
        // there is no password on the database but there cannot be less than 1 
        // characters entered here. So it's a whitespace.
        connectProps.put("password", " ");
        try {
            // connect to the derby URL using the given username and password or if
            // there is no database create one.
            connect = DriverManager.getConnection("jdbc:derby:Pizza_AllieBeckman;create=true", connectProps);
            // current url for pre created database "jdbc:derby://localhost:1527/pizza" 
        }catch(SQLException e){
        }
    }
    
    public Connection getConnection() throws SQLException{
        
        return connect;
    }
    
    protected void createTables(Connection con)throws SQLException{
        
        // create a statement to send information to the new database
        Statement stmt = con.createStatement();
        
        // use the tableExist method to find out if each table already exists
        // if it does not then create it.
        boolean pizzaSizeTableExists = tableExist(con, "PIZZASIZE");
        boolean pizzaCrustTableExists = tableExist(con, "PIZZACRUST");
        boolean pizzaToppingsTableExists = tableExist(con, "TOPPINGS");
        
        if (!pizzaSizeTableExists){
            
            // create a string for the table that will hold the pizza sizes
            String tableSize = "CREATE TABLE pizzasize\n" +
                "(\n" +
                "size char(20)\n" +
                ")";
            stmt.execute(tableSize); // create the table
        
            
             // create strings for the commands to populate the table
            String sizeOne = "INSERT INTO pizzasize (size)\n" +
                "VALUES ('Extra-Large')";
            String sizeTwo = "INSERT INTO pizzasize (size)\n" +
                "VALUES ('Large')";
            String sizeThree = "INSERT INTO pizzasize (size)\n" +
                "VALUES ('Medium')";
            String sizeFour = "INSERT INTO pizzasize (size)\n" +
                "VALUES ('Small')";
        
            // populate the table
            stmt.execute(sizeOne);
            stmt.execute(sizeTwo);
            stmt.execute(sizeThree);
            stmt.execute(sizeFour);
            
        }else{
            
            System.out.println("table size already exists");
        }
        
        if (!pizzaCrustTableExists){
            
            String tableCrust = "CREATE TABLE pizzacrust\n" +
            "(\n" +
            "crust char(20)\n" +
            ")";
            stmt.execute(tableCrust);
            
            // create strings for the commands to populate the table
            String crustOne = "INSERT INTO pizzacrust (crust)\n" +
                "VALUES ('Deep Dish')";
            String crustTwo = "INSERT INTO pizzacrust (crust)\n" +
                "VALUES ('Gut Buster')";
            String crustThree = "INSERT INTO pizzacrust (crust)\n" +
                "VALUES ('Hand-Tossed')";
            String crustFour = "INSERT INTO pizzacrust (crust)\n" +
                "VALUES ('Stuffed Crust')";
            String crustFive = "INSERT INTO pizzacrust (crust)\n" +
                "VALUES ('Thin')";
        
            // populate the table
            stmt.execute(crustOne);
            stmt.execute(crustTwo);
            stmt.execute(crustThree);
            stmt.execute(crustFour);
            stmt.execute(crustFive);
            
        }else{
            
            System.out.println("Crust table already exists");
        }
        
        if(!pizzaToppingsTableExists){
            String tableToppings = "CREATE TABLE toppings\n" +
                "(\n" +
                "toppings char(20)\n" +
                ")";
            stmt.execute(tableToppings);
            
            // create strings for the commands to populate the table
            String topOne = "INSERT INTO toppings (toppings)\n" +
                "VALUES ('sausage')";
            String topTwo = "INSERT INTO toppings (toppings)\n" +
                "VALUES ('ham')";
            String topThree = "INSERT INTO toppings (toppings)\n" +
                "VALUES ('pepperoni')";
            String topFour = "INSERT INTO toppings (toppings)\n" +
                "VALUES ('greenpeppers')";
            String topFive = "INSERT INTO toppings (toppings)\n" +
                "VALUES ('mushrooms')";
            String topSix = "INSERT INTO toppings (toppings)\n" +
                "VALUES ('olives')";
            String topSeven = "INSERT INTO toppings (toppings)\n" +
                "VALUES ('chicken')";
        
            // populate the table
            stmt.execute(topOne);
            stmt.execute(topTwo);
            stmt.execute(topThree);
            stmt.execute(topFour);
            stmt.execute(topFive);
            stmt.execute(topSix);
            stmt.execute(topSeven);
            
        }else{
            
            System.out.println("toppings table already exists");
        }
    }
    /**
     * This is a method to check the current database to see if the tables needed
     * for this application already exist. If they don't the program creates them.
     * @param con
     * @param tableName
     * @return
     * @throws SQLException 
     */
    public static boolean tableExist(Connection con, String tableName) throws SQLException {
    
        // boolean to be returned
        boolean doesTableExist;
    
        // gets all the data from the current database
        DatabaseMetaData md = con.getMetaData();
        // searches for the table passed to this method (current table being searched for)
        ResultSet result = md.getTables(null, null, tableName, null);
        
        // if it finds a matching table then it exists and wont be created (returns true)
        if (result.next()){
            doesTableExist = true;
        }else{
            // table does not exist if it cannot be found and returns false to be created
            doesTableExist = false;
        }
        
        return doesTableExist;
    }
}
