
package employeeproductionworker_alliebeckman;

public class InvalidEmployee {
    
}
