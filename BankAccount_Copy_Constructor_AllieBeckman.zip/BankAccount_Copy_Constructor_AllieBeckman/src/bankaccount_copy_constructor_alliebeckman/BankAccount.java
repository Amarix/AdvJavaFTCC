/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bankaccount_copy_constructor_alliebeckman;

/**
 *
 * @author Allie
 */
public class BankAccount {
    
    private double balance; // Account balance
    /**
     * This constructor sets the starting balance at 0.0.
     * 
     */
    
    public BankAccount()
    {
        balance = 0.0;
    }
    
    /**
     * Copy constructor. This constructor accepts a reference to another
     * BankAccount object. The object that is constructed is a copy of the
     * argument object.
     * @paran obj A reference to a BankAccount object
     */
    
    public BankAccount(BankAccount obj)
    {
        balance = obj.balance;
    }
    
    /**
     * This constructor sets the starting balance to the value passed as an
     * argument.
     * @paran startBalance The starting balance
     */
    
    public BankAccount(double startBalance)
    {
        balance = startBalance;
    }
    
    // Provide return value for each bank account
    
    public double getBalance()
    {
        return balance;
    }
    
    
}
