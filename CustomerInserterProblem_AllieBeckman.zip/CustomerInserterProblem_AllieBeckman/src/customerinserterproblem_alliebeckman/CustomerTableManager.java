/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package customerinserterproblem_alliebeckman;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author Allie
 */
public class CustomerTableManager {
    
    // Create a named constant for the URL.
    // NOTE: This value is specific for Java DB
    public final String DB_URL = "jdbc:derby:CoffeeDB";
    
    // Field for the database connection
    private Connection conn;
    
    // Constructor
    public CustomerTableManager() throws SQLException{
        //Create a connection to the database.
        conn = DriverManager.getConnection(DB_URL);
    }
    
    public void insert(String custNum, String name, String address, String city,
            String state, String zip) throws SQLException{
        String query = "INSERT INTO Customer VALUES" + "(" + "'" + custNum + "' " +
                name + "' " + address + "' " + city + "' " + state + "' " + zip + "'"
                + ")";
    
        // Create a Statement object
        Statement stat = conn.createStatement();
    
        // Close the statement
        conn.close();
        stat.close();
    }
}
