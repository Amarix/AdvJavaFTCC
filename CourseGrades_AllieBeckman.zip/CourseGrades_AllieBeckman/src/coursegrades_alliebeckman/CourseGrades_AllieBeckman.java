
package coursegrades_alliebeckman;

public class CourseGrades_AllieBeckman {

    public static void main(String[] args) {
        

        // a new class with predefined grades
        CourseGrades finalGrades = new CourseGrades();
        
        // set he grade that is saved in the class for each activity.
        // can later accept arguments to manually put in grades if needed.
        finalGrades.setLab();
        finalGrades.setEssay();
        finalGrades.setPassFail();
        finalGrades.setFinal();
        
        // print list of numeric and letter grades for each class.
        System.out.println(finalGrades.toString());

    }
    
}
