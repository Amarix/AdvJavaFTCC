
package pizzeria_alliebeckman;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class PizzaCrust {
    
    // an array for the crust options data
    private final String[] crust = new String[5];
    
    /**
     * takes data from the table Crust and places it into an array
     * @param pd
     * @throws SQLException 
     */
    public void pizzaCrust(Connection pd) throws SQLException
    {
        // create the bridge that creates commands to send and recieve data to the
        // database.
        Statement stmt = pd.createStatement();
        
        // translate data into variables.
        ResultSet result = stmt.executeQuery("SELECT * FROM pizzacrust");
        
        // counter for the array
        int i = 0;
        
        while (result.next()){ // continues running for each new piece of data in
            // the crust column
            String newCrust = result.getString("crust"); // a string that holds the current value of data.
            crust[i] = newCrust; // add string to array.
            i++;
        }
    }
    
    /**
     * returns filled array of crust options
     * @return 
     */
    public String[] getCrust(){
        return crust;
    }
}
