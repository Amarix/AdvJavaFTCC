/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package personalinformationclass_alliebeckman;

/**
* create a class that holds objects that are user information.
* 8/17/2016
* CSC 251 Lab 5 - Personal Information Class
* @author Allie Beckman
*/
public class PersonalInformationClass_AllieBeckman 
{   
    public static void main(String[] args){
            // Create the objects.
            Person me = new Person();
            Person myFriend1 = new Person();
            Person myFriend2 = new Person();
            
            // Set my info.
            me.setName("Allie Beckman");
            me.setAge(24);
            me.setAddress("112 Raleigh ln");
            me.setPhone("(999)329-0099");
            
            // Set friend #1's info.
            myFriend1.setName("Elizabeth Shankle");
            myFriend1.setAge(22);
            myFriend1.setAddress("223 Raleigh rd");
            myFriend1.setPhone("(442)232-2013");
            
            // Set friend #2's info.
            myFriend2.setName("Lisha");
            myFriend2.setAge(26);
            myFriend2.setAddress("602 Garner Ave");
            myFriend2.setPhone("(235)252-2623");
            
            // Display my info
            
            System.out.println("my information: ");
            System.out.println("Name: "+me.getName());
            System.out.println("Age: "+me.getAge());
            System.out.println("Address: "+me.getAddress());
            System.out.println("Phone: "+me.getPhone());
            
            // Display my friend1s info
            System.out.println();
            System.out.println("my information: ");
            System.out.println("Name: "+myFriend1.getName());
            System.out.println("Age: "+myFriend1.getAge());
            System.out.println("Address: "+myFriend1.getAddress());
            System.out.println("Phone: "+myFriend1.getPhone());     
            
            // Display my friend2s info
            System.out.println();
            System.out.println("my information: ");
            System.out.println("Name: "+myFriend2.getName());
            System.out.println("Age: "+myFriend2.getAge());
            System.out.println("Address: "+myFriend2.getAddress());
            System.out.println("Phone: "+myFriend2.getPhone());  
    }
}
