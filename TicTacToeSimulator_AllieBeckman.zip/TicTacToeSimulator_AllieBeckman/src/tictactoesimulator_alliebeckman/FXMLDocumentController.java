/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tictactoesimulator_alliebeckman;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

/**
 *
 * @author Allie
 */
public class FXMLDocumentController implements Initializable {
         
    @FXML
    public Label lblWinLose;
    @FXML
    public Button btnNewGame;
    @FXML
    public ImageView ivOne;
    @FXML
    public ImageView ivTwo;
    @FXML
    public ImageView ivThree;
    @FXML
    public ImageView ivFour;
    @FXML
    public ImageView ivFive;
    @FXML
    public ImageView ivSix;
    @FXML
    public ImageView ivSeven;
    @FXML
    public ImageView ivEight;
    @FXML
    public ImageView ivNine;
    
    // create a new game bord for each button click
    private gameBord game = new gameBord();
      
    @FXML
    public void handleButtonAction(ActionEvent event) {

        // use the method that puts the Xs and Os as 1s and 2s in the array that is
        // the game bord
        game.game();
        // refrence the array that is the game board
        int[][] tBoard = game.getImageArray();
        // use the method in the display controller to assign images to the display
        // based on the 1s and 2s in the game board array
        this.setImages(tBoard);
        // use the win message method in the game class to display the winning text 
        // on the display label
        lblWinLose.setText(game.getWinMessage());
        }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
       
    }
    
    // a method to assign images to the image views based on the array from the game board array
    public void setImages(int[][] tBoard){    
        Image one;
        Image two;
        Image three;
        Image four;
        Image five;
        Image six;
        Image seven;
        Image eight;
        Image nine;
        
        switch (tBoard[0][0]){
            case 1: one = new Image(getClass().getResource("o.png").toExternalForm());
            break;
            case 2: one = new Image(getClass().getResource("x.png").toExternalForm());
            break;
            default: one = new Image(getClass().getResource("background.png").toExternalForm());
        }
        switch (tBoard[1][0]){
            case 1: two = new Image(getClass().getResource("o.png").toExternalForm());
            break;
            case 2: two = new Image(getClass().getResource("x.png").toExternalForm());
            break;
            default: two = new Image(getClass().getResource("background.png").toExternalForm());
        }
        switch (tBoard[2][0]){
            case 1: three = new Image(getClass().getResource("o.png").toExternalForm());
            break;
            case 2: three = new Image(getClass().getResource("x.png").toExternalForm());
            break;
            default: three = new Image(getClass().getResource("background.png").toExternalForm());
        }
        switch (tBoard[0][1]){
            case 1: four = new Image(getClass().getResource("o.png").toExternalForm());
            break;
            case 2: four = new Image(getClass().getResource("x.png").toExternalForm());
            break;
            default: four = new Image(getClass().getResource("background.png").toExternalForm());
        }
        switch (tBoard[1][1]){
            case 1: five = new Image(getClass().getResource("o.png").toExternalForm());
            break;
            case 2: five = new Image(getClass().getResource("x.png").toExternalForm());
            break;
            default: five = new Image(getClass().getResource("background.png").toExternalForm());
        }
        switch (tBoard[2][1]){
            case 1: six = new Image(getClass().getResource("o.png").toExternalForm());
            break;
            case 2: six = new Image(getClass().getResource("x.png").toExternalForm());
            break;
            default: six = new Image(getClass().getResource("background.png").toExternalForm());
        }
        switch (tBoard[0][2]){
            case 1: seven = new Image(getClass().getResource("o.png").toExternalForm());
            break;
            case 2: seven = new Image(getClass().getResource("x.png").toExternalForm());
            break;
            default: seven = new Image(getClass().getResource("background.png").toExternalForm());
        }
        switch (tBoard[1][2]){
            case 1: eight = new Image(getClass().getResource("o.png").toExternalForm());
            break;
            case 2: eight = new Image(getClass().getResource("x.png").toExternalForm());
            break;
            default: eight = new Image(getClass().getResource("background.png").toExternalForm());
        }
        switch (tBoard[2][2]){
            case 1: nine = new Image(getClass().getResource("o.png").toExternalForm());
            break;
            case 2: nine = new Image(getClass().getResource("x.png").toExternalForm());
            break;
            default: nine = new Image(getClass().getResource("background.png").toExternalForm());
        }
        
        ivOne.setImage(one);
        ivTwo.setImage(two);
        ivThree.setImage(three);
        ivFour.setImage(four);
        ivFive.setImage(five);
        ivSix.setImage(six);
        ivSeven.setImage(seven);
        ivEight.setImage(eight);
        ivNine.setImage(nine);
    }
}

