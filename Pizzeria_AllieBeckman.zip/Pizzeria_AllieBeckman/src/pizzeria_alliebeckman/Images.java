
package pizzeria_alliebeckman;

import javafx.scene.image.Image;

public class Images {
    
    // create arrays for the images to be sent in bulk to another class
    private final Image[] toppingsImage = new Image[8];
    private final Image[] sizeImage = new Image[4];
    private final Image[] crustImage = new Image[5];
    
    // a method to turn the images from the resources folder into variables to populate
    // the image arrays
    public void Images(){
        
        toppingsImage[0] = new Image(getClass().getClassLoader().getResource("Resources/sausage.png").toString(), true);
        toppingsImage[1] = new Image(getClass().getClassLoader().getResource("Resources/ham.png").toString(), true);
        toppingsImage[2] = new Image(getClass().getClassLoader().getResource("Resources/pepperoni.png").toString(), true);
        toppingsImage[3] = new Image(getClass().getClassLoader().getResource("Resources/greenPeppers.png").toString(), true);
        toppingsImage[4] = new Image(getClass().getClassLoader().getResource("Resources/mushrooms.png").toString(), true);
        toppingsImage[5] = new Image(getClass().getClassLoader().getResource("Resources/olives.png").toString(), true);
        toppingsImage[6] = new Image(getClass().getClassLoader().getResource("Resources/chicken.png").toString(), true);
        toppingsImage[7] = new Image(getClass().getClassLoader().getResource("Resources/blank.png").toString(), true);
        
        sizeImage[0] = new Image(getClass().getClassLoader().getResource("Resources/ExtraLargeSize.jpg").toString(), true);
        sizeImage[1] = new Image(getClass().getClassLoader().getResource("Resources/LargeSize.jpg").toString(), true);
        sizeImage[2] = new Image(getClass().getClassLoader().getResource("Resources/MediumSize.jpg").toString(), true);
        sizeImage[3] = new Image(getClass().getClassLoader().getResource("Resources/SmallSize.jpg").toString(), true);
        
        crustImage[0] = new Image(getClass().getClassLoader().getResource("Resources/pan.png").toString(), true);
        crustImage[1] = new Image(getClass().getClassLoader().getResource("Resources/gutBuster.png").toString(), true);
        crustImage[2] = new Image(getClass().getClassLoader().getResource("Resources/handTossed.png").toString(), true);
        crustImage[3] = new Image(getClass().getClassLoader().getResource("Resources/stuffedCrust.png").toString(), true);
        crustImage[4] = new Image(getClass().getClassLoader().getResource("Resources/thinCrust.png").toString(), true);
    }
    
    /**
     * these three methods return each of the different arrays for size, crust type, and toppings.
     * @return 
     */
    public Image[] getTopImages(){
        return toppingsImage;
    }
    public Image[] getSizeImages(){
        return sizeImage;
    }
    public Image[] getCrustImages(){
        return crustImage;
    }
}
