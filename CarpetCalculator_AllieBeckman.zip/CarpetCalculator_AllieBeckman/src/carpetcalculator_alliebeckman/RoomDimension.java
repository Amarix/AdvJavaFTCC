/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package carpetcalculator_alliebeckman;

public class RoomDimension {
       
    private double Length; // variable length of the room to be used in this class
    private double Width; // variable width of the room to be used in this class
    private double Area; // variable Area of the room to be used in this class
    
    /**
     * Initializes the
     * length and width
     * @param length length of the room
     * @param width width of the room
     */
    public RoomDimension(double length, double width){

        Length = length; // assign the values gathered from the main class
        Width = width;  // to the values in this class RoomDimension to be used
                        // to find the area of the users carpet
        
        Area = length*width; // calculate the area
    }
    
    // return the area obtained from the method RoomDimension
    public double getArea(){
        
        return Area; // returns the double value of the room size
    }
    
    // a method to convert double to string to print redable results
    public String toString(){
        
        String results = Double.toString(Area); // to convert double to string
        
        return results; // to return results to main class to be printed in output
                        // for testing purposes
        
    }
}
