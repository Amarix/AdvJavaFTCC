
package monthexceptions_alliebeckman;

public class InvalidMonthNumberException extends Exception {
    /**
     * Constructor
     */
    public InvalidMonthNumberException(){
        super("ERROR: Invalid month number. ");
    }
}
