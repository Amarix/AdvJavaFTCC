
package monthexceptions_alliebeckman;

import java.util.Arrays;
import java.util.List;

public class Month {
    // variables for either month num or month name
    int monthNumber;
    String monthName;
    
    // method to decide if the month is an int or a string
    public Month(String month) throws InvalidMonthNameException, InvalidMonthNumberException{
        
        // check if it is an int first
        try{
            
            monthNumber = Integer.parseInt(month);
            // call the month num valid method
            checkMonthNumberValid(monthNumber);
            
        }catch(NumberFormatException e){
            // it is a string
            monthName = month;
            // use the new string as the argument to check if the month is
            // a valid month
            checkMonthValid(monthName);
            
        }
    }
    
    /**
     * Check if the month string is a valid month
     * @param mN 
     * @throws monthexceptions_alliebeckman.InvalidMonthNameException 
     */
    public void checkMonthValid(String mN) throws InvalidMonthNameException{
        
        // create a list of all the acceptable months
        List<String> monthList = Arrays.asList("january", "february", "march", "april", 
                "may", "june", "july",  "august", "september", "october", 
                "november", "december");
        
        // check to see if the users month is in the list
        // make everything lowercase.
        boolean isMonthValid = monthList.contains(mN.toLowerCase());
        
        // throw exceptoin if month name isn't valid
        if (isMonthValid == true){
            
            monthName = mN.toUpperCase();
            
        }else{
            
            throw new InvalidMonthNameException();
        }
    }
    
    /**
     * Check to see if the new month number is within 1 to 12
     * @param mNum
     * @throws InvalidMonthNumberException 
     */
    public void checkMonthNumberValid(int mNum) throws InvalidMonthNumberException{
        // create a list of month all possible month numbers
        List<Integer> monthNumList = Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12);
        
        boolean isMonthValid = monthNumList.contains(mNum);
        
        if (isMonthValid == true){

            monthName = Integer.toString(mNum);
            
        }else{
            throw new InvalidMonthNumberException();
        }
    }
    
    /**
     * get month name String
     * @return 
     */
    public String getMonthName(){
        return monthName;
    }
    
    /**
     * get month number
     * @return
     */
    public int getMonthNumber(){
        return monthNumber;
    }
}
