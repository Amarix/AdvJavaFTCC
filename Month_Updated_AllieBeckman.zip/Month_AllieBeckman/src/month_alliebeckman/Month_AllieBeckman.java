/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package month_alliebeckman;

import java.util.Arrays;
import java.util.Scanner;
import javax.swing.JOptionPane;

/**
* A project that takes a month from a user and converts it from either a string or an int to its corresponding string or int.
* 09/08/2016
* CSC 251 Homework 1 - Month Class
* @ author Allie Beckman
*/
public class Month_AllieBeckman {
    
    public static void main(String[] args)// initates a string array class
    {
        // get users month
        String myMonth = JOptionPane.showInputDialog("whats the month?");
        
        try{
           
            // check if it's an int
           int myMonthNumber = Integer.parseInt(myMonth);

            Month myNewMonth = new Month(myMonthNumber); // runs myMonthNumber in the class Month if an int is found
            System.out.println(myNewMonth); // print the results of Month
            
        }catch(NumberFormatException notANumber){
           
            // if its not an int call the month class using the string method
           Month myNewMonth = new Month(myMonth); // run myMonth in the class Month as a string
           System.out.println(myNewMonth); // print the results of Month
        }
    }
}


