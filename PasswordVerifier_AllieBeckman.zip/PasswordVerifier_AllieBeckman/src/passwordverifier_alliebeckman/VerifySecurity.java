
package passwordverifier_alliebeckman;

public class VerifySecurity {

    // the string to be retned after validation
    public String result;

    /**
     * method to test all requirements for 
     * the Amazon password that the user has entered
     * @param pass
     * @return 
     */
    public String Verify(String pass){
        
        // bool is true if password has lowercase
        boolean includesUpppercase = !pass.equals(pass.toLowerCase());
        
        // bool is true if pass has uppercase
        boolean includeLowercase = !pass.equals(pass.toUpperCase());
        
        // is false if password is under 5 chars
        boolean isAtLeastFiveChars = pass.length() >= 5;
        
        // // is true if pass does not have a space
        boolean passDoesNotHaveASpace = !(pass.contains(" "));
        
        
        // check to make sure all booleans are true
        if (includesUpppercase == true && includeLowercase == true
                && isAtLeastFiveChars == true && passDoesNotHaveASpace == true)
        {
            // if bools are true password is valid
            result = "Thank you. Your password is valid.";
            
        }else{
            // if they aren't all true password is invalid
            result = "Sorry, your password is not valid. Please try again.";
            
        }
        
        // return results
        return result;
    }
}
