/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package customerinserterproblem_alliebeckman;

import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author Allie
 */
public class CustomerInfoPanel extends JPanel{
    
    private JTextField custNumTextField; // customer number
    private JTextField nameTextField; // name
    private JTextField addressTextField; // address
    private JTextField cityTextField; // city
    private JTextField stateTextField; // state
    private JTextField zipTextField; // zip
    
    public CustomerInfoPanel(){
        // Create labels and text fields
        // for the customer data.
        JLabel custNumPrompt = new JLabel("Customer Number");
        custNumTextField = new JTextField(10);
        
        JLabel namePrompt = new JLabel("Name");
        nameTextField = new JTextField(25);
        
        JLabel addressPrompt = new JLabel("Address");
        custNumTextField = new JTextField(10);
        
        JLabel cityPrompt = new JLabel("City");
        nameTextField = new JTextField(12);
        
        JLabel statePrompt = new JLabel("State");
        custNumTextField = new JTextField(2);
        
        JLabel zipPrompt = new JLabel("Zip Code");
        nameTextField = new JTextField(25);
        
        // Create a grid layout manager
        // with 12 rows and 1 column.
        setLayout(new GridLayout(12, 1));
        setBorder(BorderFactory.createTitledBorder("Enter Customer Information"));
        
        // Add the labels and text fields to the panel.
        add(custNumPrompt);
        add(custNumTextField);
        
        add(namePrompt);
        add(nameTextField);
        
        add(addressPrompt);
        add(addressTextField);
        
        add(cityPrompt);
        add(cityTextField);
        
        add(statePrompt);
        add(stateTextField);
        
        add(zipPrompt);
        add(zipTextField);
    }
    
    /**
     * The getCustNum method returns the customer number entered by the user
     */
    public String getCustNum(){
        return custNumTextField.getText();
    }
    
    /**
     * The getName method returns the customer name entered by the user
     */
    public String getName(){
        return nameTextField.getText();
    }
    
    /**
     * The getAddress method returns the customer Address entered by the user
     */
    public String getAddress(){
        return addressTextField.getText();
    }
    
    /**
     * The getCity method returns the customer City entered by the user
     */
    public String getCity(){
        return cityTextField.getText();
    }
    
    /**
     * The getState method returns the customer State entered by the user
     */
    public String getState(){
        return stateTextField.getText();
    }
    
    /**
     * The getZip method returns the customer zip code entered by the user
     */
    public String getZip(){
        return zipTextField.getText();
    }
    
    public void clear(){
        custNumTextField.setText("");
        nameTextField.setText("");
        addressTextField.setText("");
        cityTextField.setText("");
        stateTextField.setText("");
        zipTextField.setText("");
    }
}
