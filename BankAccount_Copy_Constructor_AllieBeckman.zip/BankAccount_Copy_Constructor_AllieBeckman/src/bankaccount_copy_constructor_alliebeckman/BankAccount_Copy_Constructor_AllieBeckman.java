
package bankaccount_copy_constructor_alliebeckman;

import java.text.DecimalFormat;

/**
* A project constructing bank accounts and providing their value in dollar
* decimal format.
* 8/25/2016
* CSC 251 Lab 7 - BankAccount Class Copy Constructor
* @author Allie Beckman
*/
public class BankAccount_Copy_Constructor_AllieBeckman {

    public static void main(String[] args) {
        // Create BankAccount object with abalance of $1200.00
        BankAccount account1 = new BankAccount(1200.0);
        
        // Create another BankAccount object as a copy of the first.
        BankAccount account2 = new BankAccount(account1);
        
        /**
         * One more account to show each account can have a different value
         * and to insure decimal format is working properly.
         */
        BankAccount account3 = new BankAccount(3023.0057);
        
        // Create a DecimalFormat object to format the balance when displayed
        DecimalFormat dollar = new DecimalFormat("#,##0.00");
        
        // Display the balance in each account.
        System.out.println("The balance in bank account one is "+
                dollar.format(account1.getBalance()));
        System.out.println("The balance in bank account two is "+
                dollar.format(account2.getBalance()));
        System.out.println("The balance in bank account three is "+
                dollar.format(account3.getBalance()));
        
        System.exit(0);
    }
    
}
