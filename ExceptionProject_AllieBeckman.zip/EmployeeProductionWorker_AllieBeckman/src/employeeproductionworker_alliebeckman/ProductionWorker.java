
package employeeproductionworker_alliebeckman;

import java.text.DecimalFormat;


public class ProductionWorker extends Employee{
   
    // Constants for the day and night shifts
    public static final int DAY_SHIFT = 1;
    public static final int NIGHT_SHIFT = 2;
    
    private int shift; // The employee's shift
    private double payRate; // The emplolyee's pay rate
    
    /**
     * this constructor initializes an object with a name
     * employee number, hire date, shift and pay rate 
     * @param n the name
     * @param num the number
     * @param date the date hired
     * @param sh the shift
     * @param rate the employees pay rate
     * @throws employeeproductionworker_alliebeckman.InvalidEmployeeNumber
     * @throws employeeproductionworker_alliebeckman.InvalidShift
     * @throws employeeproductionworker_alliebeckman.InvalidPayRate
     */
    
    public ProductionWorker (String n, String num, String date,
            int sh, double rate) 
            throws InvalidEmployeeNumber, 
            InvalidShift, 
            InvalidPayRate
    {
        super(n, num, date);
        setShift(sh);
        setPayRate(rate);
    }
    
    /**
     * The no-arg constructor initalizes an object with null strings for name,
     * employee number and hire date. The day shift is selected and the pay
     * rate is set to 0.0
     */
    
    public ProductionWorker()
    {
        super();
        shift = DAY_SHIFT;
        payRate = 0.0;
    }
    
    /**
     * the setshift sts the employee shift
     * @param s The employee shift
     * @throws employeeproductionworker_alliebeckman.InvalidShift
     */
    
    public void setShift(int s) throws InvalidShift{
        if ( s != DAY_SHIFT && s != NIGHT_SHIFT){
            throw new InvalidShift();
        }else{
            shift = s;
        }
    }
    
    /**
     * The set pay rate method sets the employee pay rate
     * @param p the pay rate
     * @throws employeeproductionworker_alliebeckman.InvalidPayRate
     */
    
    public void setPayRate(double p) throws InvalidPayRate{
        if (p < 0){
            throw new InvalidPayRate();
        }else{
            payRate = p;
        }
    }
    /**
     * the get shift method returns the shift
     * @return the employee shift
     */
    
    public int getShift(){
        return shift;
    }
    
    /** the get pay rate sets the employees pay rate
     * @return the employees pay rate
     */
    
    public double getPayRate(){
        return payRate;
    }
    
    /**
     * to string
     * @return A reference to a string representation of the object
     */
    
    public String toString(){
        
        DecimalFormat dollar = new DecimalFormat("##0.00");
        
        String str = super.toString();
        
        str += "\nShift: ";
        
        if(shift == DAY_SHIFT){
            str += "Day";
        }
        else if (shift == NIGHT_SHIFT){
            str += "Night";
        }else{
            str += "INVALID SHIFT NUMBER";
        }
        
        str += ("\nHourly Pay Rate: $" + dollar.format(payRate));
        
        return str;
    }
}
