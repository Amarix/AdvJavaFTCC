
package coursegrades_alliebeckman;

// a class to define a graded activity and use the numeric grade to produce the
// letter grade of each activity
public class GradedActivity {
    
    // set these to default incase a value is not given.
    private char grade = 'F';
    private double score = 0;
    
    // recieve a new score for each assignment
    public void setScore (double s){
        score = s;
    }
    
    // a method for calling back the numeric score of an activity
    public double getScore (){
        return score;
    }
    
    // a method to produce the corrisponding letter grade to it's numeric value
    public char getGrade(){
        
        if(score >= 90){
            grade = 'A';
        }else if(score >= 80){
            grade = 'B';
        }else if(score >= 70){
            grade = 'C';
        }else if (score >= 60){
            grade = 'D';
        }else{
            grade = 'F';
        }
        
        return grade;
    }
    
    // a to string method to print the letter and number grade for this new activity.
    public String toString(){
        String Final = "Your letter grade is: "+String.valueOf(grade)
                +" Your numeric grade is: "+String.valueOf(score);
        return Final;
    }
}
