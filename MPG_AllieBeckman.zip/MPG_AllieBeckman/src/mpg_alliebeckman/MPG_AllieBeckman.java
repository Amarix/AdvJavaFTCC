/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mpg_alliebeckman;

import java.util.Scanner;

/**
* obtain information from user to display their mpg.
* 8/17/2016
* CSC 251 Lab 1 - Miles per Gallon
* @author Allie Beckman
*/
public class MPG_AllieBeckman {

    public static void main(String[] args) {
        
        // create variables
        double miles;
        double gallons;
        double mpg;
        
        Scanner keyboard = new Scanner(System.in);
        
        System.out.println("Enter miles driven: ");
        miles = keyboard.nextDouble();
        
        System.out.println("Enter gallons used: ");
        gallons = keyboard.nextDouble();
        
        mpg = miles/gallons;
        
        System.out.println("The MPG is "+mpg+".");
    }
    
}
