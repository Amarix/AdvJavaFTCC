
package employeeproductionworker_alliebeckman;

public class InvalidPayRate extends Exception {
    /**
     * Constructor
     */
    public InvalidPayRate()
    {
        super("ERROR: Negative pay rate.");
    }
}
