
package employeeproductionworker_alliebeckman;

public class InvalidShift extends Exception {
    /**
     * Constructor
     */
    public InvalidShift()
    {
        super("ERROR: Invalid shift number. ");
    }
}
