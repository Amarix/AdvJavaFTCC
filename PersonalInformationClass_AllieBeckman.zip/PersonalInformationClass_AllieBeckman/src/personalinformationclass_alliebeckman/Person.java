/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package personalinformationclass_alliebeckman;

/**
 *
 * @author Allie
 */
public class Person {
    private String name; // persons name
    private String address; // address
    private int age; // persons age
    private String phone; // persons phone number
    
    /**
     * The no-arg constructor initializes an empty object
     */

    public Person()
    {
        name = "";
        address = "";
        age = 0;
        phone = "";
    }
    /**
     * The parameterized constructor accepts arguments for the objects fields.
     *      @Paran myName A persons name.
     *      @Paran myAddress persons address.
     *      @Paran myAge a persons age.
     *      @Paran myPhone persons phone number.
     */
    public void setName(String myName)
    {
        name = myName;
    }
    // The setAddress method sets a person address
    public void setAddress(String myAddress){
        address = myAddress;
    }
    // The setAge method sets a person age
    public void setAge(int myAge){
        age = myAge;
    }
    //the setPhone method sets a person phone number
    public void setPhone(String myPhone){
        phone = myPhone;
    }
    
    // get name method returns persons name
    public String getName(){
        return name;
    }
    // get age method
    public int getAge(){
        return age;
    }
    // get address method
    public String getAddress(){
        return address;
    }
    // get phone number method
    public String getPhone(){
        return phone;
    }
    
    
    public static void main(String[] args){
        
    }
}
