/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package carpetcalculator_alliebeckman;

import javax.swing.JOptionPane;

/**
* create a program to calculate the cost of carpet for any given room
* 9/14/16
* CSC 251 Project 1 -Carpet Calculator
* @author Allie Beckman
*/
public class CarpetCalculator_AllieBeckman {


    public static void main(String[] args) {

        double myRoomLength; // users length of room
        double myRoomWidth; // users width of room
        double costPerSquareFoot; // users carpet cost per square foot
        
        
        // gather the users information to initalize the varables
        myRoomLength = Double.parseDouble(JOptionPane.showInputDialog("Please enter your room length:"));
        myRoomWidth = Double.parseDouble(JOptionPane.showInputDialog("Please enter your room width:"));
        costPerSquareFoot = Double.parseDouble(JOptionPane.showInputDialog("What is the cost of your carpet per square foot?"));
        
        
        // call the RoomDeminsion class to find the area of the room using the users
        // variable values for length and width
        RoomDimension thisRoom = new RoomDimension(myRoomWidth, myRoomLength);
        
        System.out.println("The area of your room is:");
        System.out.println(thisRoom); // print the users room area
        
        // call the RoomCarpet class to find the cost per square foot using the users
        // variable value for cost per square foot and the area value gathered from RoomDemension
        RoomCarpet carpetCost = new RoomCarpet(thisRoom, costPerSquareFoot);
        
        System.out.println("The cost of your carpet will be:");
        System.out.println(carpetCost + " Dollars"); // print the users carpet cost
    }
    
}
