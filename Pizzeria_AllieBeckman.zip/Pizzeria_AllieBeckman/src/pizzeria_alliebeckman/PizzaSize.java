
package pizzeria_alliebeckman;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class PizzaSize {
    
    // an array to hold the pizza size options
    private final String[] size = new String[4];
    
    /**
     * a method to gather the data from the size table and add it to the size array
     * @param pd
     * @throws SQLException 
     */
    public void pizzaSize(Connection pd) throws SQLException
    {
        // create the bridge that creates commands to send and recieve data to the
        // database.
        Statement stmt = pd.createStatement();
        
        // translate data into variables.
        ResultSet result = stmt.executeQuery("SELECT * FROM pizzasize");
        
        // counter for the array
        int i = 0;
        
        while (result.next()){ // continues running for each new piece of data in
            // the size column 
            String newSize = result.getString("size"); // a string that holds the current value of data.
            size[i] = newSize; // add string to array.
            i++; 
        }
    }
    
    /**
     * returns the filled size option array
     * @return 
     */
    public String[] getSize(){
        return size;
    }
    
}
