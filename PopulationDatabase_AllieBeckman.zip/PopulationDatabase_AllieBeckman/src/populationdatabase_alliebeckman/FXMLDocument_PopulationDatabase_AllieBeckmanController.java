/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package populationdatabase_alliebeckman;

import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Arrays;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.event.ActionEvent;
import javafx.scene.control.Label;

/**
 *
 * @author Allie
 */
public class FXMLDocument_PopulationDatabase_AllieBeckmanController implements Initializable {

    // connect the TableView from the xml file
    @FXML
    private TableView<City> CityTable;
    
    // connect the table columns from the xml file
    @FXML
    private TableColumn<City, String> CityName;
    @FXML
    private TableColumn<City, String> Population;
    
    // create an observable list to fill with data from DB and populate TableView
    private final ObservableList<City> dta = FXCollections.observableArrayList();

    // object to hold row values
    private City cty;
    
   // create an xml item to connect to the choice box using the fx:id named
    // on the scene builder
    @FXML
    private ComboBox GetBox;
    
    // label for the combobox
    @FXML
    private Label GetLabel;
    
    // an array to hold the population
    private double populationArray[] = new double[20];
    
    // create a variable that will contain the answer to the choice in the choice box
    private double choiceBoxAnswer;
    
    // a variable that will hold the users selection from the combo box
    private String choiceBoxQuestion;
    
    // max population variable
    private double max = populationArray[0];
    
    // min population variable
    private double min = populationArray[0];
    
    // total population variable
    private double total = 0;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        //GetBox.getItems().addAll("Highest Population", "Lowest Population", "Total Population");
        //GetBox.setValue("Highest Population");
        try{
            // call the driver used to connect to the database
            Class.forName("org.apache.derby.jdbc.EmbeddedDriver").newInstance();
            
            // connect to the city data base
            Connection c = DriverManager.getConnection("jdbc:derby://localhost:1527/CityDB;create=true", "AllieBeckman", "1122");
        
            // create a statement used to sort through the data in the database
            Statement stmt = c.createStatement();
            
            // create a result that will be used to get the data and translate it into variables
            ResultSet result = stmt.executeQuery("SELECT * FROM city");

            // counter for population number array
            int i = 0;
            
            // continue sorting through and translating data until there are no more rows of data
            while (result.next()){
                
                // print each line of data to check if it's right
                System.out.println(result.getString("cityname") + result.getDouble("population"));
                
                // make a new city object with each row in the database CityDB
                cty = new City(result.getString("cityname"), "" + result.getDouble("population"));

                // fill array with population of each city
                populationArray[i] = Double.parseDouble(cty.population.getValue());

                // get total population
                total = total + Double.parseDouble(cty.population.getValue());
                // continue sorting through the array if it's not over the ammount
                // of citys in list
                if (i < 19){
                    i++;
                }

                // add the new city object to the observable list
                dta.add(cty);
            }
            
            // print the observable list to make sure it's full
            System.out.println(dta);
                  
            // assign the columns in your tableview to the proper data in the city object
           CityName.setCellValueFactory(cellData -> cellData.getValue().cityname);
           Population.setCellValueFactory(cellData -> cellData.getValue().population);
            
            // populate the tableview with the observable list
            CityTable.setItems(dta);
            
            // close the connection
            c.close();
            
        }catch(Exception e){
            System.out.println("Failed");
            System.out.println(e);
        }

        // sort array from smallest to largest
        Arrays.sort(populationArray);

        // add min and max to variable
        max = populationArray[19];
        min = populationArray[0];

        System.out.println(max);
        System.out.println(min);
        System.out.println(total);
    }
    
    @FXML
    private void handleButtonAction(ActionEvent event) {

        
        // check that the system is printing the right selected item
        System.out.println(GetBox.getSelectionModel().getSelectedItem().toString());
    
        // converts the text from the comboBox to a string to be used as a case in the switch
        // statements
        choiceBoxQuestion = (GetBox.getSelectionModel().getSelectedItem().toString());
        
        // a switch statement to switch between each combo box option
        switch (choiceBoxQuestion){
            case "Highest Population": choiceBoxAnswer = max;
            break;
            case "Lowest Population": choiceBoxAnswer = min;
            break;
            case "Total Population": choiceBoxAnswer = total;  
        }

        // set the label text to the answer
        GetLabel.setText(Double.toString(choiceBoxAnswer));
    }
    
}
