/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package customerinserterproblem_alliebeckman;

import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;



/**
 *
 * @author Allie
 */
public class CustomerInserterProblem_AllieBeckman extends JFrame{

    CustomerInfoPanel customerInfoPanel; // Panel for customer information
    JPanel buttonPanel; // Panel for buttons
    
    /**
     * Constructor
     */
    public CustomerInserterProblem_AllieBeckman()
    {
        // Set the window title
        setTitle("Add Customer");
        
        // Specify an action for the close button
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // Create a CustomerInfoPanelObject
        customerInfoPanel = new CustomerInfoPanel();
        
        // Build the buttonPanel object
        buildButtonPanel();
        
        // Add the panels to the content pane
        add(customerInfoPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
        
        // Pack and display the window
        pack();
        setVisible(true);
    }
    
    /**
     * buildButtonPanel method
     */
    private void buildButtonPanel()
    {
        // Create a panel for the buttons
        buttonPanel = new JPanel();
        
        // Create a submit button and add an action listener
        JButton submitButton = new JButton("Submit");
        submitButton.addActionListener(new SubmitButtonListener());
        
        // Create an Exit button
        JButton exitButton = new JButton("Exit");
        exitButton.addActionListener(new ExitButtonListener());
        
        // Add the buttons to the panel.
        buttonPanel.add(submitButton);
        buttonPanel.add(exitButton);
    }
    
    /**
     * Private inner class that handles submit button events
     */
    private class SubmitButtonListener implements ActionListener
    {
        
        public void actionPerformed(ActionEvent e){
            
            try
            {
                // Get the customer information from the text fields
                String custNum = customerInfoPanel.getCustNum();
                String name = customerInfoPanel.getName();
                String address = customerInfoPanel.getAddress();
                String city = customerInfoPanel.getCity();
                String state = customerInfoPanel.getState();
                String zip = customerInfoPanel.getZip();
                
                // Create a CustomerTableManager object
                CustomerTableManager ctManager = new CustomerTableManager();
                
                // Insert the record
                ctManager.insert(custNum, name, address, city, state, zip);
                
                // clear the text fields
                customerInfoPanel.clear();
                
                // Let the user know the record was added.
                JOptionPane.showMessageDialog(null, "Record Added");
            }
            catch (SQLException ex){
                ex.printStackTrace();
                System.exit(0);
            }
        }
    }
    
    /**
     * Private inner class that handles Exit Button events
     */
    private class ExitButtonListener implements ActionListener
    {
        public void actionPerformed(ActionEvent e){
            // Exit the app
            System.exit(0);
        }
    }
    
    /**
     * main method
     */
    public static void main(String[] args){
        new CustomerInserterProblem_AllieBeckman();
    }
    
}
