/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package carpetcalculator_alliebeckman;

public class RoomCarpet {
    
    private double carpetCost; // variable for this class to be used for cost
                               // per square foot
    
    private RoomDimension Size; // variable to collect the area of the room from
                                // RoomDimension class
    
    public RoomCarpet(RoomDimension size, double cost){

        double roomSize = size.getArea(); // use the getArea method in RoomDimension
                                          // to get the double of the roomsize
                                          
        carpetCost = roomSize * cost; // multiply cost of carpet per square foot
                                      // by the area of the room
   
    }
    
    public double getTotalCost(){ // method to return decimal value of total carpet
                                  // cost after it's been multiplied in the room carpet method
        
        return carpetCost; // returns the decimal value of the carpets cost
    }
    
    public String toString(){
        
        String results = Double.toString(carpetCost); // to convert double to string
        
        return results; // print results of cost of carpet
    }
}
