package populationdatabase_alliebeckman;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
* Model class for a City.
*/
public class City {

    public final SimpleStringProperty cityname;
    public final SimpleStringProperty population;

    /**
     * Default constructor.
     */
    public City() {
        this(null, null);
    }

    /**
     * Constructor with some initial data.
     * 
     * @param cityname
     * @param population
     */
    public City(String cityname, String population) {
        this.cityname = new SimpleStringProperty(cityname);
        this.population = new SimpleStringProperty(population);
    }

    public String getCityName() {
        return cityname.get();
    }

    public void setCityName(String cityname) {
        this.cityname.set(cityname);
    }

    public StringProperty cityNameProperty() {
        return cityname;
    }

    public String getPopulation() {
        return population.get();
    }

    public void setPopulation(String population) {
        this.population.set(population);
    }

    public StringProperty populationProperty() {
        return population;
    }
}
