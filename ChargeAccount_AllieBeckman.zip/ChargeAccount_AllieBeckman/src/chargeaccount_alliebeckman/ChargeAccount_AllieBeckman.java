
package chargeaccount_alliebeckman;

import javax.swing.JOptionPane;

/**
* check account information to insure the account can be charged.
* 8/17/2016
* CSC 251 Lab 6 - Charge Account Validation
* @author Allie Beckman
*/
public class ChargeAccount_AllieBeckman {

    public static void main(String[] args) {
        String input; // to hold keyboard input
        int accountNumber; // accunt number to validate
        
        // Create a Validator object.
        Validator val = new Validator();
        
        // Get a charge account number
        input = JOptionPane.showInputDialog("Enter your charge account number: ");
        accountNumber = Integer.parseInt(input);
        
        // Determine whether it is valid.
        if (val.isValid(accountNumber))
            JOptionPane.showMessageDialog(null, "That's a valid account number.");
        else
            JOptionPane.showMessageDialog(null, "That's an invalid account number.");
        System.exit(0);
    }
    
}
