/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tictactoesimulator_alliebeckman;

import java.util.Arrays;
import java.util.Random;

public class gameBord {
    
    // tic tac toe bord
    private int[][] tBoard;    
    private final Random r = new Random(); // a random int between 1 and 2 will be chosen to define x and o  
    private String winMessage; // string to be displayed on lable to display winner
    private int foundWinner = 0;

    
    // creates the board and moves
    public void game(){
        
        // clear board
        tBoard = new int[3][3];
        
        // game has started and there has not been a winner
        foundWinner = 0;
        
        // Player X goes first the program determines who went last based on 
        // what this variable is set to. If it's set to 1 then O went last and it will
        // set it to 2 in the while loop.
        int player = 1;
        
        // x and y are the index's of the game board
        int x;
        int y;
        
        // while loop keeps going until someone gets 3 in a row
        while (foundWinner == 0){
       
            // generates a random index in the 2D array
            x = r.nextInt(3);
            y = r.nextInt(3);
            
            if (tBoard[x][y] == 0){
                
                // set the next player
                if (player == 1){
                    player = 2;
                    
                    // places the x or o at the random location
                    tBoard[x][y] = player;
                    
                }else if (player == 2){
                    player = 1;
                    
                    // places the x or o at the random location on the board
                    // that does not already have an X or O in it.
                    tBoard[x][y] = player;
                }  
            }  
            // checks to see if either player got 3 in a row.
            this.checkForWinner();
 
        }
    }
   
    // checks through all possible wins and gets which letter has matched 3 in a row
    // first then displays the winner
    public void checkForWinner(){
        
        // an int to make sure all three spaces match
        int match = 0;
        
        // these if statements represent every possible way to win 3 in a row.
        if (tBoard[0][0] == tBoard[0][1] && tBoard[0][1] == tBoard[0][2]){
            
            // if the int = 3 that means there were 3 ones if it's 6 it means there were 3 2s
            match = (tBoard[0][0] + tBoard[0][1] + tBoard[0][2]);
        }
        if (tBoard[1][0] == tBoard[1][1] && tBoard[1][1] == tBoard[1][2]){
            match = (tBoard[1][0] + tBoard[1][1] + tBoard[1][2]);
        }
        if (tBoard[2][0] == tBoard[2][1] && tBoard[2][1] == tBoard[2][2]){
            match = (tBoard[2][0] + tBoard[2][1] + tBoard[2][2]);
        }
        if (tBoard[0][0] == tBoard[1][0] && tBoard[1][0] == tBoard[2][0]){
            match = (tBoard[0][0] + tBoard[1][0] + tBoard[2][0]);
        }
        if (tBoard[0][1] == tBoard[1][1] && tBoard[1][1] == tBoard[2][1]){
            match = (tBoard[0][1] + tBoard[1][1] + tBoard[2][1]);
        }
        if (tBoard[0][2] == tBoard[1][2] && tBoard[1][2] == tBoard[2][2]){
            match = (tBoard[0][2] + tBoard[1][2] + tBoard[2][2]);
        }  
        if (tBoard[0][0] == tBoard[1][1] && tBoard[1][1] == tBoard[2][2]){
            match = (tBoard[0][0] + tBoard[1][1] + tBoard[2][2]);
        }
        if (tBoard[0][2] == tBoard[1][1] && tBoard[1][1] == tBoard[2][0]){
            match = (tBoard[0][2] + tBoard[1][1] + tBoard[2][0]);
        }
        
        // if there are no more empty spaces on the board (no more 0's in the array)
        // and there has not been a winner yet, this declares it a cats game.
        if (!Arrays.deepToString(tBoard).contains("0")){
            match = 9;
        }
        
        // this prints out the 2D array to view locations of 1s and 2s in the array.
        System.out.println(Arrays.deepToString(tBoard));
        
        // this switch statement has 3 possible end game cases. if match is equal
        // to 3 then there are 3 ones in a row and O wins.
        // if match is equal to 6 that means there were 3 twos in a row and the
        // winner is X.
        // if all of the spaces are full and there is not three in a row then it's
        // a tie or "cats game"
        // default means there are still spaces left and no winner so the while loop
        // in the game method will continue looping.
        switch (match){
            case 3: winMessage = "O wins the game.";
                    foundWinner = 1;
            break;
            case 6: winMessage = "X wins the game.";
                    foundWinner = 1;
            break;
            case 9: winMessage = "Cats game";
                    foundWinner = 1;         
            break;
            default: foundWinner = 0;
            break;
                    
            }
        
        
    }
    
    // returns the saved numbers that will represent the images for the display
    public int[][] getImageArray(){
        
        return tBoard;
    }
    
    // returns the win message
    public String getWinMessage(){
        return winMessage;
    }
}
