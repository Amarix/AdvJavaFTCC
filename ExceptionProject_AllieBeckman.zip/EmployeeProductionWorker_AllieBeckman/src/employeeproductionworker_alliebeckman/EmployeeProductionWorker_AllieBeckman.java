
package employeeproductionworker_alliebeckman;
/**
* A program that holds employee information and throws exceptions if
* the information is invalid
* 10/5/16
* CSC 251 Lab 10 - Exception Project
* @author Allie Beckman
*/

public class EmployeeProductionWorker_AllieBeckman {

    
    public static void main(String[] args) {
        // Create a productionworker object and pass the initialization data
        // to the constructor
        
        createWorker("John Smith", "123-A",
        "11-15-2005", ProductionWorker.DAY_SHIFT, 16.50);
        
        System.out.println();
        System.out.println("Attempt invalid employee number: ");
        createWorker("Joan Jones", "22-L", "12-12-2005", ProductionWorker.NIGHT_SHIFT, 18.50);
        
        System.out.println();
        System.out.println("Attempt invalid shift number. ");
        createWorker("Joe Shmoe", "123-B", "11-14-2012", 66, 16.50);
        
        System.out.println();
        System.out.println("Attempt an invalid pay rate");
        createWorker("Ellen Mellon", "332-C", "11-21-2013", ProductionWorker.DAY_SHIFT, -33);
    }
    
    public static void createWorker(String n, String num, String date, int sh, double rate){
        ProductionWorker pw;
        
        // Attempt to create an instance of the ProductionWorker
        // class. and catch any resulting execptions
        
        try{
            pw = new ProductionWorker(n, num, date, sh, rate);
            
            // if we make it to this point the object was sussesfully created.
            
            System.out.println("Object created. ");
            System.out.println(pw);
            
        }
        catch(InvalidEmployeeNumber e){
            System.out.println(e.getMessage());
        }
        catch(InvalidShift e){
            System.out.println(e.getMessage());
        }
        catch(InvalidPayRate e){
            System.out.println(e.getMessage());
        }
    }
    
}

    

