
package monthexceptions_alliebeckman;

public class InvalidMonthNameException extends Exception{
    /**
     * Constructor
     */
    public InvalidMonthNameException(){
        super("ERROR: Invalid month name. ");
    }
}
