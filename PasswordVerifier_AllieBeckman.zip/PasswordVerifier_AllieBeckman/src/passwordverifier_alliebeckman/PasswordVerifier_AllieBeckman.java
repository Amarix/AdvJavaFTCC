/**
* A software for Amazon to check users' passwords insuring they have at least
* one capital letter, one lowercase letter, and one number.
* 9/21/16
* CSC 251 Homework 2 - Password Verifier
* @author Allie Beckman
*/
package passwordverifier_alliebeckman;

import javax.swing.JOptionPane;


public class PasswordVerifier_AllieBeckman {

    public static void main(String[] args) {
       
        // obtain users password
        String password = JOptionPane.showInputDialog("Welcome! Please enter your Amazon Password. It must have one uppercase one lowercase and one number. It cannot include spaces:");
        
        // call method from verifySecurity class
        VerifySecurity checkPass = new VerifySecurity();
        
        // use the class to exicute its verify method
        String isPassValid = checkPass.Verify(password);
        
        
        JOptionPane.showMessageDialog(null, isPassValid);
    }
    
}
