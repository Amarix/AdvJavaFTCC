/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package retailpricecalculator_alliebeckman;

import java.net.URL;
import java.text.DecimalFormat;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

/**
* A program that takes the wholesale price, and markup percentage of an item
* and produces the retail price
* 
* 10/13/16
* 
* CSC 251 Lab 11 - Retail Price Calculator
* @author Allie Beckman
*/
public class FXMLDocumentController implements Initializable {
    
    // make variables for the components with the fx:ids
    @FXML
    private Label outputLabel; // retail price display
    @FXML
    private TextField wholesaleTextField; // where the user enters the wholesale price
    @FXML
    private TextField markupTextField; // where the user enters the markup percentage

    public double wholesalePrice; // the users wholesale price
    public double markupPct; // the users markup percentage
    public double retailPrice; // the calculated retail price
    public double markupPrice; // teh calculated markup price
    
    @FXML
    private void handleButtonAction(ActionEvent event) {
        
        // a format for a dollar amount
        DecimalFormat d = new DecimalFormat("0.00");
        
        try
        {
            // get the wholesale price from the text field
            wholesalePrice = Integer.parseInt(wholesaleTextField.getText());
            
            try
            {
                // get the markup percentage and devide it by 100 to get the decimal
                markupPct = (Double.parseDouble(markupTextField.getText())/ 100);
            
                // markup price will be how much more the user is paying than the wholesale price
                markupPrice = wholesalePrice * markupPct;
        
                // retail price will be the amount more than the user is paying plus wholesale
                retailPrice = markupPrice + wholesalePrice;
        
                // print the new retail price in the dollar format created above
                outputLabel.setText("Your Item will cost $" +  (d.format(retailPrice)));     
            }
            catch(Exception f)
            {
                // if the markupPct text field does not contain a double
                outputLabel.setText("Please enter a valid markup percentage");
            }
        
        
        }
        catch(Exception e)
        {
            // if the wholesalePrice text field does not contain a double
            outputLabel.setText("Please enter a valid wholesale Price.");
        }   
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
    }
    
}
