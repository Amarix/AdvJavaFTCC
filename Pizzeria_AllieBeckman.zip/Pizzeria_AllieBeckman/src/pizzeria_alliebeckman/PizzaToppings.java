
package pizzeria_alliebeckman;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class PizzaToppings {
    
    // an array to hold the topping options data from the toppings table in the
    // database
    private final String[] toppings = new String[7];
    
    /**
     * A method to sort through the toppings table adding each topping to the
     * array of toppings.
     * @param pd
     * @throws SQLException 
     */
    public void pizzaToppings(Connection pd) throws SQLException
    {
        // create the bridge that creates commands to send and recieve data to the
        // database.
        Statement stmt = pd.createStatement();
        
        // translate data into variables.
        ResultSet result = stmt.executeQuery("SELECT * FROM toppings");
        
        // counter for the array
        int i = 0;
        
        while (result.next()){ // continues running for each new piece of data in
            // the toppings column
            String newTopping = result.getString("toppings"); // a string that holds the current value of data.
            // take out any extra whitespace after the topping
            newTopping = newTopping.replaceAll("\\s+$", "");
            toppings[i] = newTopping; // add string to array.
            i++;
        }
    }
    
    /**
     * returns the filled toppings array
     * @return 
     */
    public String[] getToppings(){
        return toppings;
    }
}
