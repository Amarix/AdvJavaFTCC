/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package timecalculator_alliebeckman;

import javax.swing.JOptionPane;

/**
* Convert user input seconds to mins, hours, and days.
* 8/17/2016
* CSC 251 Lab 2 - Time Calculator
* @author Allie Beckman
*/
public class TimeCalculator_AllieBeckman {


    public static void main(String[] args) {
        
        double seconds; // user number of seconds
        String input; // to hold keyboard input
        
        // constants
        final double SECONDS_PER_MINUTE = 60.0; // seconds in a min
        final double SECONDS_PER_HOUR = 3600.0; // seconds in an hour
        final double SECONDS_PER_DAY = 86400.0; // seconds in a day
        
        // Number of seconds from user
        input = JOptionPane.showInputDialog("Enter the number of seconds you would like to convert: ");
        seconds = Double.parseDouble(input);
        
        // Display the number of mins if any
        if (seconds >= SECONDS_PER_MINUTE){
            
            // Calculate the number of minutes.
            double minutes = seconds / SECONDS_PER_MINUTE;
            
            // display mins
            JOptionPane.showMessageDialog(null,"There are "+minutes+" minutes in "+seconds+" seconds.");         
        }
        if (seconds >= SECONDS_PER_HOUR){
            
            // calculate the number of hours
            double hours = seconds / SECONDS_PER_HOUR;
            
            // display hours
            JOptionPane.showMessageDialog(null, "There are "+hours+" hours in "+seconds+" seconds.");
        }
        if (seconds >= SECONDS_PER_DAY){
            
            // calculate the number of days
            double days = seconds/ SECONDS_PER_DAY;
            
            // display days
            JOptionPane.showMessageDialog(null,"There are "+days+" days in "+seconds+" seconds.");
            
        }
        
        // Exit the application
        System.exit(0);
    }
    
}
